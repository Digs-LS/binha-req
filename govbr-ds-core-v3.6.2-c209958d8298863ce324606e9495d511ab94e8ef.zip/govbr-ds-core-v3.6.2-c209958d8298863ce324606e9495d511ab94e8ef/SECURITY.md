# Reportando problemas de segurança

Nós do time GOVBR-DS, juntamente com a comunidade, levamos segurança muito a sério.

Solicitamos que informem pelo discord a necessidade de discussão de assuntos sensíveis. Algum membro do time entrará em contato para entender melhor a situação.

Nós agradecemos todo esforço para nos reportar problemas de segurança de maneira responsável e segura. Nós vamos nos esforçar para reconhecer todas as contribuições

Iremos nos esforçar ao máximo para responder tais problemas de maneira rápida, eficiente e te mantendo atualizado.
