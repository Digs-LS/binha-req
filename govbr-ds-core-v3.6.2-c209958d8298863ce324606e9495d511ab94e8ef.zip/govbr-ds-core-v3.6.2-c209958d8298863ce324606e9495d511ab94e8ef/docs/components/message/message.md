O *Message* (Mensagem) é um Componente de Interface que tem como finalidade proporcionar *feedback* ao usuário sobre o que ocorre no sistema.
