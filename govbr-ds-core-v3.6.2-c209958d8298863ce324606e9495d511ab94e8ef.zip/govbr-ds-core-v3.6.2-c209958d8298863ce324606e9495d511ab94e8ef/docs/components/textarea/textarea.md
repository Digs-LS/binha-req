O *Textarea* é um campo de entrada de texto que permite que seu aplicativo aceite um valor de texto potencialmente longo do usuário.
