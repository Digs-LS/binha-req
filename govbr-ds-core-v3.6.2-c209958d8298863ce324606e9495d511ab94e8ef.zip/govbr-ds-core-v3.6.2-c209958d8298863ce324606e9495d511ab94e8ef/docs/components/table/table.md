A *Table* (Tabela) é um conjunto de dados organizados em linhas e colunas.
