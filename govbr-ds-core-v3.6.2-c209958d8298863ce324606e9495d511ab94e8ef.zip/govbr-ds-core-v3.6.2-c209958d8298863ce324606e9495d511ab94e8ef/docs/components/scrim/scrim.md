<div class="br-message warning" role="alert">
    <div class="icon" aria-label="Componente Obsoleto">
        <i class="fas fa-exclamation-triangle fa-lg" aria-hidden="true"></i>
    </div>
    <div class="content">
        <p><strong>Componente Obsoleto/Depreciado.</strong></p>
        <p>O uso desse componente é <strong>desencorajado</strong> devido as novas diretrizes do <strong>Design System GOV.BR</strong>.</p>
        <p>Utilize o <a href="/ds/util/scrim/">Utilitário JS > Scrim</a> e leia a documentação visual em <a href="/ds/padroes/ajuda/">Padrões > Ajuda e Comunicação</a>.</p>
    </div>
</div>

Scrims são tratamentos temporários que podem ser aplicados às superfícies dos elementos de uma interface com o objetivo de tornar o conteúdo menos proeminente.
