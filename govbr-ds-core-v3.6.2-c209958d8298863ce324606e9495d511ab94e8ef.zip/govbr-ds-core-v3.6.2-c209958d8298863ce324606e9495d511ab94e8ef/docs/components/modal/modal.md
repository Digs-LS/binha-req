Modal é uma janela que exibe um conteúdo adicional em uma camada acima da página atual, com uma sobreposição de superfície (*overlay*) cobrindo a página e tornando-a temporariamente inacessível.
