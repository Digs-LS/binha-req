*Divider*, também conhecido como **Divisor** ou **Separador**, é uma linha neutra que separa conteúdos, sessões ou temas afins.
