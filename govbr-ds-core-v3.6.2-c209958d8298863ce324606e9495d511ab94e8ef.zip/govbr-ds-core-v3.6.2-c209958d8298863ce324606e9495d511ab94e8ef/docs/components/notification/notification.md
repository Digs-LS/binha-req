*Notification* (notificação) são mensagens enviadas por aplicativos ou *sites* que fornecem informações curtas, oportunas e relevantes ao usuário.
