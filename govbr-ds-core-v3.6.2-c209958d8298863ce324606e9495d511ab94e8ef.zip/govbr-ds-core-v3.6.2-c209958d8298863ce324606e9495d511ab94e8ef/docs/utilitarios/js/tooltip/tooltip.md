<div class="br-message info" role="alert">
<div class="icon" aria-label="Informação"><i class="fas fa-info-circle fa-lg" aria-hidden="true"></i></div>
<div class="content">
<p><strong>Dependência externa.</strong></p>
<p>Este componente usa o vendor <a href="https://popper.js.org/">Popper</a>. Em caso de dúvidas leia a documentação de <a href="/ds/guias/uso-de-vendors">Uso de Vendors</a>.</p>
</div>
</div>
</div>
