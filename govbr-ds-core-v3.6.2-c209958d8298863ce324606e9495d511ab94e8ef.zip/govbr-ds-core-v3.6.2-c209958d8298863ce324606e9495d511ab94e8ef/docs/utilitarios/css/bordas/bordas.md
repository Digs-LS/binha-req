As classes foram criadas baseadas no [Fundamento Superfície](fundamentos-visuais/superficie).

![Exemplo de bordas](imagens/bordas2.png)

| Borda sólida        | Borda tracejada      |
| ------------------- | -------------------- |
| `border-solid-none` | `border-dashed-none` |
| `border-solid-sm`   | `border-dashed-sm`   |
| `border-solid-md`   | `border-dashed-md`   |
| `border-solid-lg`   | `border-dashed-lg`   |
